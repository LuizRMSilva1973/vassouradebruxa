Coloque estes arquivos SDF aqui (você pode baixar pelos links abaixo):
- caspofungina (CID 16119814, base livre): https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/CID/16119814/SDF?record_type=3d
- ibrexafungerp (CID 46871657): https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/CID/46871657/SDF?record_type=3d

Observações:
- Prefira 'record_type=3d' quando disponível para usar no docking (o script converte para PDBQT).
- Você também pode usar .mol/.mol2/.pdb. Se começar com SMILES, gere 3D com sua ferramenta preferida.
